package ui.controller;

import java.util.List;

/**
 * <b>INTERFACE DECLARANT LES OPERATIONS D'INTERFACE UTILISATEUR SUR L'ENTITE 'T'</b>
 * <b>INTERFACE GENERIQUE : ELLE S'APPLIQUE A L'ENTITE ABSTRAITE 'T'</b>
 * 
 *
 * @param <T>
 */
public interface IController<T> {

	/**
	 * <b>ENREGISTRER UNE ENTITE 'T'.</b>
	 * @return   L'entit� 'T' enregistr�e.
	 */
	public abstract void enregistrer();
	
	/**
	 * <b>RECHERCHER UNE ENTITE 'T' PAR IDENTIFIANT.</b>
	 * @param pId L'identifiant de l'entit� � rechercher.
	 * @return   L'entit� 'T' trouv�e.
	 */
	public abstract void rechercherParIdentifiant();
	
	/**
	 * <b>RECHERCHER TOUTES LES ENTITES 'T'.</b>
	 * @return   La liste des entit�s trouv�es.
	 */
	public abstract List<T> rechercherListe();
	
	/**
	 * <b>MODIFIER UNE ENTITE 'T'.</b>
	 * @param pT L'entit� 'T' � modifier.
	 * @return   L'entit� 'T' modifi�e.
	 */
	public abstract T modifier(T pT);
	
	/**
	 * <b>SUPPRIMER UNE ENTITE 'T'.</b>
	 * @param pId L'identifiant de l'entit� � supprimer.
	 * @return   L'entit� 'T' supprim�e.
	 */
	public abstract T supprimer();
	
}
