package ui.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import business.exception.EntityAlreadyExistsException;
import business.exception.EntityNotFoundException;
import persistence.dao.PersonneDAO;
import persistence.entity.Personne;

/**
 * <b>CLASSE DECLARANT LES OPERATIONS D'INTERFACE UTILISATEUR SUR L'ENTITE 'PERSONNE'</b>
 * <b>INTERFACE NON GENERIQUE : ELLE S'APPLIQUE A L'ENTITE CONCRETE 'PERSONNE'</b>
 * 
 */
public class PersonneController implements IController<Personne>{

	
	private PersonneDAO personneDAO;
	private static Scanner scanner;
	
	/**
	 * <b>CONSTRUCTEUR SANS ARGUMENT</b>
	 */
	public PersonneController () {
		this.personneDAO = new PersonneDAO();
	}
	
	public void menuPrincipal()
	{
		PersonneController.scanner = new Scanner(System.in);

		// this.afficherBienvenue();

		int choix = 0;
		boolean continuerSaisie = false;

		do {
			do {
				System.out.println("Veuillez choisir une option :");

				//////////////////////////////////////////////////////////////////////////
				// (02.01) Afficher liste d'options
				//////////////////////////////////////////////////////////////////////////
				ActionUtilisateur[] action = ActionUtilisateur.values();
				for (ActionUtilisateur actionUtilisateur : action) {
					System.out.println(actionUtilisateur.toString());
				}

				choix = scanner.nextInt();

				//////////////////////////////////////////////////////////////////////////
				// (02.03) Definir la condition de maintien en boucle
				//////////////////////////////////////////////////////////////////////////

				if (choix < 0 || choix > 6)
					System.out.println("Vous n'avez pas saisi une action valide");
			} while (choix < 0 || choix > 6);

			continuerSaisie = (choix != 0);

			switch (choix) {
			case 0:
				System.out.println("Goodbye !");
				break;
			case 1:
				enregistrer();
				break;
			case 2:
				rechercherParIdentifiant();
				break;
			case 3:
				rechercherListe();
				break;
			case 4:
				modifierListe();
				break;
			case 5:
				supprimer();
				break;
			}
		} while (continuerSaisie);

	}
	
	@Override
	public void enregistrer() {
		

		System.out.println("+------------------------------------------------------------+");
		System.out.println("| VEUILLEZ SAISIR LES INFORMATIONS RELATIVES A LA PERSONNE : |");
		System.out.println("+------------------------------------------------------------+");

		try {
			scanner.nextLine();
			long id = personneDAO.getLastId();
			System.out.println("Veuillez saisir un nom :");
			String nom = scanner.nextLine();
			System.out.println("Veuillez saisir un prenom :");
			String prenom = scanner.nextLine();
			System.out.println("Veuillez saisir un age :");
			int age = scanner.nextInt();
			scanner.nextLine();
	
			Personne personneCreated = new Personne(id, nom, prenom, age);
		
			personneDAO.create(personneCreated);
			id++;
			personneDAO.setLastId(id);
		} catch (EntityAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// personneCreated = this.personneDAO.create(personneCreated);
			
	}

	@Override
	public void rechercherParIdentifiant() {
		
		Personne personneFound = null;
		
		try {
			System.out.println("Quel identifiant recherchez vous ?");
			long pId = scanner.nextInt();
			personneFound = this.personneDAO.findById(pId);
			System.out.println(personneFound.toString());
			
		} catch (EntityNotFoundException e) {
			System.out.println("Erreur -- " + e.getMessage());
		}
	}

	@Override
	public List<Personne> rechercherListe() {
		
		List<Personne> personnesFound = this.personneDAO.findList();
		
		for (Personne personne : personnesFound) {
			System.out.println(personne.toString());
		}
		
		return personnesFound;
	}

	@Override
	public Personne modifier(Personne pPersonne) {
		
		Personne personneUpdated = null;

		
		
		try {
			personneUpdated = this.personneDAO.update(pPersonne);
			
		} catch (EntityNotFoundException e) {
			System.out.println("Erreur -- " + e.getMessage());
		}
		return personneUpdated;
	}

	@Override
	public Personne supprimer() {
		
		Personne personneDeleted = null;
		
		try {
			rechercherListe();
			System.out.println("Quel identifiant voulez-vous supprimer ?");
			long id = scanner.nextInt();
			personneDeleted = this.personneDAO.delete(id);
			
		} catch (EntityNotFoundException e) {
			System.out.println("Erreur -- " + e.getMessage());
		}
		return personneDeleted;
	}
	
	public void modifierListe() {
		PersonneController.scanner = new Scanner(System.in);
		List<Personne> personnes = rechercherListe();
		
		System.out.println("Quel identifiant voulez-vous modifier ?");
		long pId = scanner.nextLong();
		scanner.nextLine();
		char choix;
		
		Iterator<Personne> iterator = personnes.iterator();
		
		do {
			System.out.println("Voulez vous modifier :");
			System.out.println("Le nom : tapez n");
			System.out.println("Le pr�nom : tapez p");
			System.out.println("L'age : tapez a");
			choix = scanner.nextLine().charAt(0);
			if(choix != 'n' && choix != 'p' && choix != 'a') {
				System.out.println("Mauvaise saisie !");
			}
		} while(choix != 'n' && choix != 'p' && choix != 'a');
			
		while (iterator.hasNext()) {
			Personne p = iterator.next();
			if (pId == p.getId()) {
				if(choix == 'n') {
					System.out.printf("Par quel nom voulez vous remplacer %s\n", p.getNom());
					String nom = scanner.nextLine();
					p.setNom(nom);
				}
				else if(choix == 'p') {
					System.out.printf("Par quel pr�nom voulez vous remplacer %s\n", p.getPrenom());
					String prenom = scanner.nextLine();
					p.setNom(prenom);
				}
				else {
					System.out.printf("Par quel age voulez vous remplacer %d\n", p.getPrenom());
					int age = scanner.nextInt();
					p.setAge(age);
				}
				try {
					personneDAO.update(p);
				} catch (EntityNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
}
