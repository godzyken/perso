package ui.controller;

public enum ActionUtilisateur {
	
	///////////////////////////////////////////////////////////////////////////
	//(1.)OBJETS DIRECTEMENT CONSTRUITS
	///////////////////////////////////////////////////////////////////////////
	QUITTER           (0, "Quitter l'application"          ),
	CREER             (1, "Cr�er une personne"             ),
	RECHERCHER_PAR_ID (2, "Rechercher une personne par id" ),
	RECHERCHER_LISTE  (3, "Afficher toutes les personnes"),
	MODIFIER          (4, "Modifier une personne"          ),
	SUPPRIMER         (5, "Supprimer une personne"         );
	
	/**
	 * <b>LE NUMERO DE L'ELEMENT ENUMERE</b>
	 */
	private int id;
	   
	/**
	 * <b>LA VALEUR DE L'ELEMENT ENUMERE</b>
	 */
	private String label;
	   
	/**
	 * <b>CONSTRUCTEUR AVEC ARGUMENT</b>
	 */
	ActionUtilisateur(int pNumber, String pValue){
		this.id = pNumber;
		this.label = pValue;
	}
	   
	/**
	 * <b>RENVOYER LA VALEUR DE L'ELEMENT ENUMERE (SOUS FORME D'UNE CHAINE DE CARACTERES).</b>
	 * @return String La valeur de l'�l�ment �num�r� (sous forme d'une chaine de caract�res).
	 */
	@Override
	public String toString(){
		return "[" + this.id + "] -- [" + this.label + "]";
	}

}
