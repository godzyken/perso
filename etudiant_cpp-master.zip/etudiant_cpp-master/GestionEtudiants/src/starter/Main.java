package starter;

import ui.controller.PersonneController;

public class Main {

	public static void main(String[] args) {
		
		/////////////////////////////////////////////////
		//(01.)CREER UN OBJET DE TYPE 'PERSONNE-UI'
		/////////////////////////////////////////////////
		PersonneController personneController = new PersonneController();
		personneController.menuPrincipal();
//		personneController.modifierListe();
		
	}
}
