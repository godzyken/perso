package persistence.entity;

/**
 * <b>DEFINITION DE L'ENTITE 'PERSONNE'</b>
 * @author Tcharou
 *
 */
public class Personne {

	private long id;
	private String nom;
	private String prenom;
	private int age;
	
	/**
	 * <b>CONSTRUCTEUR SANS ARGUMENTS</b>
	 */
	public Personne() {}
	
	/**
	 * <b>CONSTRUCTEUR AVEC 3 ARGUMENTS</b>
	 */
	public Personne(String pNom, String pPrenom, int pAge) {
		this.nom    = pNom;
		this.prenom = pPrenom;
		this.age    = pAge;
	}
	
	/**
	 * <b>CONSTRUCTEUR AVEC 4 ARGUMENTS</b>
	 */
	public Personne(long pId, String pNom, String pPrenom, int pAge) {
		this.id = pId;
		this.nom    = pNom;
		this.prenom = pPrenom;
		this.age    = pAge;
	}

	public long   getId    () { return this.id;     }
	public String getNom   () { return this.nom;    }
	public String getPrenom() { return this.prenom; }
	public int    getAge   () { return this.age;    }

	public void setId    (long   pId    ) { this.id     = pId;     }
	public void setNom   (String pNom   ) { this.nom    = pNom;    }
	public void setPrenom(String pPrenom) { this.prenom = pPrenom; }
	public void setAge   (int    pAge   ) { this.age    = pAge;    }

	@Override
	public String toString() {
		return "Personne [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", age=" + age + "]";
	}
	
	public String toCsv(Boolean sautDeLigne) {
		String csvRetour = this.getId() + ";" + this.getNom() + ";" + this.getPrenom() + ";" + this.getAge();
		if(sautDeLigne) {
			return csvRetour + "\n";
		}
		return csvRetour;
	}
	
	
	
}
