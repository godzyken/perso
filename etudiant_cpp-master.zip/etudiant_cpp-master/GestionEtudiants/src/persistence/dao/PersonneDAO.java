package persistence.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import business.exception.EntityAlreadyExistsException;
import business.exception.EntityNotFoundException;
import persistence.entity.Personne;

/**
 * <b>INTERFACE DECLARANT LES OPERATIONS DE PERSISTANCE SUR L'ENTITE
 * 'PERSONNE'</b> <b>INTERFACE NON GENERIQUE : ELLE S'APPLIQUE A L'ENTITE
 * CONCRETE 'PERSONNE'</b>
 */

public class PersonneDAO implements IDAO<Personne> {

	private static final String PERSONNE_FILE = "data\\etudiant.csv";
	private static final String COUNTER_FILE = "data\\counter.csv";

	@Override
	public Personne create(Personne pT) throws EntityAlreadyExistsException {
		// TODO Auto-generated method stub


		// CREATION D'UNE CHAINE DE CARACTERE POUR INCREMENTER LES ATTRIBUTS
		String personne = pT.toCsv(false);

		// ECRITURE DANS LE FICHIER "CSV"
		try {
			PrintWriter printWriter = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(new FileOutputStream(PERSONNE_FILE, true))));

			// AUTRE ECRITURE
			// printWriter.println(pT.getId() +";" + pT.getNom() + ";" + pT.getPrenom() +
			// ";" + pT.getAge() +";");
			printWriter.println(personne);

			printWriter.close(); // FERMETURE DU FLUX

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


	public long setLastId(long pId) {

		// pId = this.getLastId();

		try (PrintWriter printId = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(COUNTER_FILE))))) {

			printId.print(pId);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return pId;
		// printId.close();
	}

	public long getLastId() {
		
		long idFound = 0;

		// LECTURE DU FICHIER AFIN DE LIRE LE DERNIER "ID" ECRIT AFIN DE LE RECUPERER
		try (BufferedReader readId = new BufferedReader(new InputStreamReader(new FileInputStream(COUNTER_FILE)))) {

			String str = readId.readLine();
			idFound = Long.parseLong(str);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return idFound;
	}

	@Override
	public Personne findById(long pId) throws EntityNotFoundException {
		
		boolean hasBeenFound = false; 
		List<Personne> personnes = this.findList();

		for (Personne personne : personnes) {
			if (personne.getId() == pId)
				return personne;
		}

		hasBeenFound = true; 
		if(hasBeenFound == true) {
			throw new EntityNotFoundException("Personne non trouv�e");
		}
		return null;
	}
	
	@Override
	public List<Personne> findList() {
		Path path = Paths.get(PERSONNE_FILE);
		List<String> lignes;
		List<Personne> personnes = new ArrayList<Personne>();

		try {
			lignes = Files.readAllLines(path, StandardCharsets.ISO_8859_1);

			for (String ligne : lignes) {
				String[] elements = ligne.split("\\;");
				long l = Long.valueOf(elements[0]);
				int i = Integer.valueOf(elements[3]);
				Personne personne = new Personne(l, elements[1], elements[2], i);
				personnes.add(personne);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		return personnes;
	}

	@Override
	public Personne update(Personne pT) throws EntityNotFoundException {
		Path path = Paths.get(PERSONNE_FILE);
		String myLine = null;
		try (Stream<String> lines = Files.lines(path)) {
			myLine = lines.filter(line -> (line.split(";")[0]).equals("" + pT.getId())).findFirst().get();

		} catch (Exception e) {
			// TODO: handle exception
		}
		try (Stream<String> lines = Files.lines(path)) {
			final String search = myLine;
			List<String> replaced = lines.map(line -> line.replaceAll(search, pT.toCsv(false))).collect(Collectors.toList());
			Files.write(path, replaced);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	@Override
	public Personne delete(long pId) throws EntityNotFoundException {

		List<Personne> personnes = findList();

		try (FileOutputStream fos = new FileOutputStream(PERSONNE_FILE)) {

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Iterator<Personne> iterator = personnes.iterator();
		while (iterator.hasNext()) {
			Personne p = iterator.next();
			if (pId == p.getId()) {
				iterator.remove();
			}
		}

		for (Personne personne : personnes) {
			writeCSV(personne);
		}

		return null;
	}

	public void writeCSV(Personne personne) {
		Path path = Paths.get(PERSONNE_FILE);
		String texte;
		texte = personne.toCsv(true);
		try {
			Files.write(path, texte.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE,
					StandardOpenOption.APPEND);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
